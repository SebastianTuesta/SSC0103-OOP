/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HelloWorld;

import java.util.Scanner;

/**
 *
 * @author Sebastián
 */
public class HelloWorldApp {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Seu nome: ");
        
        String nome = sc.nextLine();       
        
        System.out.println("--------------------------");
        System.out.println("Hello, " + nome + "!");
    }
}
