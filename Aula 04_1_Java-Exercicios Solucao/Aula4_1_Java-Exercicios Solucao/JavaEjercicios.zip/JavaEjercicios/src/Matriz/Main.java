/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Matriz;

/**
 *
 * @author Sebastián
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws Exception {
        // TODO code application logic here
        Matriz a = new Matriz(2, 3);
        Matriz b = new Matriz(3, 2);

        int[] ar0 = {2, 8, 1};
        int[] ar1 = {7, 5, 3};

        int[] br0 = {9, 3};
        int[] br1 = {2, 2};
        int[] br2 = {5, 12};

        a.addRow(0, ar0);
        a.addRow(1, ar1);

        b.addRow(0, br0);
        b.addRow(1, br1);
        b.addRow(2, br2);

        a.Multiplicate(b);
    }

}
