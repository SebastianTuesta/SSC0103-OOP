/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Matriz;

/**
 *
 * @author Sebastián
 */
public class Matriz {

    private final int col;
    private final int fil;
    private int[][] matrizA;

    public Matriz(int fil, int col) {
        this.col = col;
        this.fil = fil;
        this.matrizA = new int[fil][col];
    }

    public void addElement(int i, int j, int element) throws Exception {
        if (i > this.fil) {
            throw new Exception("Fila nao valida");
        }
        if (j > this.col) {
            throw new Exception("Columnha nao valida");
        }

        this.matrizA[i][j] = element;
    }

    public void addColumn(int j, int[] column) throws Exception {
        if (j > this.col) {
            throw new Exception("Columnha nao valida");
        }
        if (column.length > this.fil) {
            throw new Exception("Tamanho de veitor nao valida");
        }

        for (int k = 0; k < this.fil; k++) {
            this.matrizA[k][j] = column[k];
        }
    }

    public void addRow(int i, int[] row) throws Exception {
        if (i > this.fil) {
            throw new Exception("Fila nao valida");
        }
        if (row.length > this.col) {
            throw new Exception("Tamanho de veitor nao valida");
        }

        for (int k = 0; k < this.col; k++) {
            this.matrizA[i][k] = row[k];
        }
    }

    public int getLenghtColumn() {
        return this.col;
    }

    public int getLengthRow() {
        return this.fil;
    }

    public int[][] getMatrix() {
        return this.matrizA;
    }

    public int getElement(int i, int j) {
        return matrizA[i][j];
    }

    public void Multiplicate(Matriz matrizB) throws Exception {
        if (this.col != matrizB.getLengthRow()) {
            throw new Exception("Matrizes nao validas");
        }

        int aRows = this.fil;
        int aColumns = this.col;

        int bRows = matrizB.getLengthRow();
        int bColumns = matrizB.getLenghtColumn();

        int[][] matrizC = new int[aRows][bColumns];

        for (int i = 0; i < aRows; i++) {
            for (int j = 0; j < bColumns; j++) {
                matrizC[i][j] = 0;
            }
        }

        for (int i = 0; i < aRows; i++) { // aRow
            for (int j = 0; j < bColumns; j++) { // bColumn
                for (int k = 0; k < aColumns; k++) { // aColumn
                    matrizC[i][j] += matrizA[i][k] * matrizB.getElement(k, j);
                }
            }
        }

        for (int i = 0; i < aRows; i++) {
            for (int j = 0; j < bColumns; j++) {
                System.out.print(matrizC[i][j] + " ");
            }
            System.out.println();
        }

    }

}
